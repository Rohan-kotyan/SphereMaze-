# Maze Sphere
Single-file three.js game wrapped with Capacitor.

## Get the APK
1. Push this repo to GitHub (branch `main`).
2. Open the **Actions** tab → **Build APK** → open the latest run.
3. Download the **MazeSphere-apk** artifact (zip), unzip, and install `app-debug.apk` on your phone
   (allow "Install unknown apps").
