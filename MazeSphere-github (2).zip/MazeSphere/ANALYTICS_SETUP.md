# Switch on Firebase Analytics (see where players struggle and quit)

You can use the same Firebase project as the leaderboard (see FIREBASE_SETUP.md) or create one now.

1. Firebase console → your project → gear icon → **Project settings → General → Your apps → Add app → Android (the robot icon)**.
2. **Android package name:** `com.stellix.spheremaze` (exactly). Nickname: SphereMaze. Skip the SHA-1 for now. Press **Register app**.
3. Press **Download google-services.json**. This is a configuration file, not a password.
4. Put that file in the **root of the GitHub repo**, next to `package.json` and `capacitor.config.json`, with exactly the name `google-services.json`. Commit it. (The build prints "Firebase config added" when it finds it.)
5. Build the APK as usual and install it. Play a few levels.
6. In Firebase: **Analytics → DebugView / Events**. Events can take up to 24 hours to show in the normal reports; **Realtime** shows the first ones within minutes.

## Events the game sends
| Event | When | Details |
|---|---|---|
| level_start | a level begins | level |
| level_win | level cleared | level, time_s, stars, hints |
| level_quit | player leaves or restarts mid-level | level, secs played |
| level_timeup | clock ran out on a timed level | level |
| hint_used | a hint is pressed | level |
| daily_start, endless_start | those modes begin | - |
| room_create, room_join | online room actions | - |

Firebase also records automatically: sessions, new and returning users, retention, country, device and app version.

## Finding the problem levels
- **Analytics → Events → level_quit → add parameter "level"**: levels with the most quits are where players give up.
- Compare **level_start** with **level_win** for the same level: a big gap means a hard level.
- Custom parameters like `level` must be registered once: **Analytics → Custom definitions → Create custom dimension** → event parameter `level` (do the same for `secs`, `time_s` as metrics if you want averages).

## Players can switch it off
Settings → "Usage stats: ON/OFF". No names, emails or IDs are sent by the game; Firebase adds its own anonymous app-instance ID.

## Do these too
- Privacy policy: say the game collects anonymous usage data (levels played, quits, device type) via Google Firebase Analytics.
- Play Console → **Data safety**: declare "App activity" and "Device or other IDs" as collected, used for analytics, not for ads.
