# Third-party notices

Maze Sphere's own code, artwork (coin, icons, mazes) and sounds are original and generated/drawn in code.
The only third-party software is:

## three.js — MIT License
Copyright © 2010-2025 three.js authors
https://github.com/mrdoob/three.js

## Capacitor — MIT License
Copyright (c) 2017-present Drifty Co.
https://github.com/ionic-team/capacitor

MIT License text (applies to both):

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.


## Lilita One font — SIL Open Font License 1.1
Copyright 2011 The Lilita One Project Authors (https://github.com/librefonts/lilitaone). Bundled via @fontsource/lilita-one.

## @capacitor-community/admob — MIT License
Rewarded video ads via Google AdMob (test ids until you add your own).

## Content audit (v10)
- Music and all sound effects (including the ratchet "screwdriver" roll sound): composed and synthesised in code by this game. No samples or recordings.
- Graphics (coin, icons, mazes, skins, themes, tutorial pictures): drawn in code (SVG / canvas / CSS). No image files or stock art.
- Names: no third-party trademarks or characters are used in item names.
- Emoji are drawn by the phone's own system font.
- Ads: Google AdMob (test ids until you add your own).

## Logo
The SphereMaze logo / app icon (purple maze sphere) was supplied by the game's owner and is their own artwork. The Stellix Studios opening logo is likewise the owner's.
