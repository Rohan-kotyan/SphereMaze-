# Switch on the real World Board (free, about 10 minutes, no card needed)

1. Go to https://console.firebase.google.com and sign in with your Google account.
2. **Add project** → name it `spheremaze` → you can turn Google Analytics off → Create.
3. Left menu **Build → Authentication → Get started → Sign-in method → Anonymous → Enable → Save**.
4. Left menu **Build → Realtime Database → Create database** → choose a location (Singapore is closest to India) → start in **locked mode**.
5. In Realtime Database open the **Rules** tab, delete everything, paste the content of `database.rules.json` (in this project), press **Publish**.
6. Gather two values:
   - **Database URL**: shown at the top of the Realtime Database page, like `https://spheremaze-xxxxx-default-rtdb.asia-southeast1.firebasedatabase.app`
   - **Web API key**: Project settings (gear icon) → General → "Web API Key".
   These two are public identifiers, not passwords, so it is safe to send them to me or paste them yourself.
7. In `www/index.html` find `const LB_CFG={db:'',key:''};` and put the two values in. (Or send them to me and I will do it and rebuild.)

Never share your Firebase account password or any "service account" / admin key with anyone.

What the rules do: only signed-in (anonymous) players can read the ranking; each player can write only their own row; a row must have the right shape; Maze IQ can only go up and never above 350; names max 12 characters.
What they cannot do: stop someone who edits their own phone's game memory from sending a fake score up to 350. Real protection against that needs a server that replays the game, which is a much bigger project.

Add to your privacy policy: the game sends the player's chosen name, avatar and Maze IQ to Firebase (Google) to show the world ranking.
